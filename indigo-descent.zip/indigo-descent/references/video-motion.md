# 运动与视频规则

## 观察到的运动语法

对四段影像连续抽帧后，可复用的运动特征：

- **一条镜头一个主运动**。多数段落是缓慢横移 + 轻微推近，镜头高度接近马胸/人眼，略低，带纪念碑感。
- **主体从运动到静止**。例如马从奔跑逐渐减速、停住，人群从虚影中浮现；静止后镜头仍在缓慢漂移，画面不会“死”。
- **前中后景速度不同**。近景人物/树枝掠过得快，中景主体稳定，远山几乎不动；形成纸面舞台的视差。
- **雾与色带承担转场**。靛蓝/朱砂的绸带状色块、雾、前景剪影都可以擦过画面，把上一段“洗”成下一段。
- **不追求物理正确的无缝**。原片允许建筑、人群、服饰在运动中轻微变形、增殖或替换；这是梦境/记忆的逻辑，不是三维相机的逻辑。
- **剪辑存在两种节奏**：`2.mp4` 是 25 秒的连续长镜头；`1.mp4` 则有明显的远景—特写—全景切换。二者都可用，但一条片子里只选一种。

没有分析音轨，不推断配乐、节拍或旁白。

## 镜头三选一

| 镜头 | 做法 | 适用 | 提示词关键词 |
| --- | --- | --- | --- |
| 横移入画 `TRUCK` | 镜头平行于画面横向移动，前景先入画，主体逐渐露出 | 山水、市集、群像 | slow lateral tracking, foreground parallax, subject revealed |
| 轻推近 `PUSH` | 从全景缓慢推近到中景/近景，背景压缩 | 人像、宠物、产品、情绪 | slow push-in, gentle dolly, background compresses |
| 退远收束 `PULL` | 从主体退到全景，留白变大，人变小 | 结尾、孤独感、史诗感 | slow pull-back, subject becomes small in vast paper void |

一条 5–8 秒镜头只选一个。不要“推近 + 摇镜 + 环绕 + 变焦”全上。

## 镜头配方

### 5 秒（默认）

- 0.0–1.0s：静态起幅，雾/尘埃先动。
- 1.0–4.0s：主运动完成 70%，主体微动（鬃毛、衣摆、呼吸）。
- 4.0–5.0s：减速，停在可接下一镜的构图。

### 8 秒

- 0.0–1.5s：起幅，给观众读图。
- 1.5–6.0s：主运动 + 一次“揭示”（前景掠过/雾散/人群让开）。
- 6.0–8.0s：减速，留 0.5s 稳定尾帧。

### 24 秒长镜头（进阶）

只在有把握时用。拆成 3 个“运动段落”，每段仍只有一个主运动；用雾/色带/前景遮挡做软过渡，不要依赖模型自动保持 24 秒稳定。

## 图生视频提示词

结构：

```text
[首帧描述/风格锁] + [主体微动作] + [一个镜头运动] + [环境运动] + [稳定约束] + [负向]
```

中文示例（人像）：

```text
暖象牙旧纸上的东方岩彩电影插画，靛蓝与墨蓝结构，朱砂与赭金点睛，细刻线、矿物颗粒、雾层与留白。
画面中的女子保持同一张侧脸与同一件靛蓝立领长袍，极轻地呼吸，发丝与衣摆被微风缓慢吹动。
镜头从半身缓慢推近到胸口以上，背景的远山与赭金圆盘几乎不动，雾从画面右侧缓慢漫入。
纸纹、颗粒、色温保持稳定；人物五官、手指、衣领结构不变形。
负向：镜头翻滚、快速变焦、肢体增殖、脸融化、手指变形、建筑抖动、山体漂移、闪烁、随机文字、水印。
```

英文示例：

```text
A cinematic mineral-pigment illustration on warm ivory paper. Indigo and ink-blue structure the image, with restrained vermilion and ochre accents, fine engraved lines, pigment granulation, drifting mist, and generous negative space.
The woman keeps the same profile and the same indigo high-collar robe; she breathes almost imperceptibly, while loose hair and the hem drift in a slow breeze.
The camera pushes in gently from a half-body shot to a chest-up shot. The distant mountain band and the ochre sun disc stay nearly still; mist creeps in from the right edge.
Stable paper grain, stable color temperature, stable facial features, hands and collar. No morphing, no extra limbs, no flicker, no text.
```

## 参数起始值

| 参数 | 建议 | 说明 |
| --- | --- | --- |
| 时长 | 5s（默认）/ 8s | 越长越容易漂移 |
| 帧率 | 24fps | 电影感；不要 60fps 的电视感 |
| 运动幅度 | 1–3 / 10 | 低运动是稳定与高级感的前提 |
| 镜头运动 | 1–2 / 10 | 只给一个方向 |
| 首帧 | 必选 | 用风格化后的图，不要用原始照片 |
| 尾帧 | 有则更好 | 首尾帧能显著减少漂移 |
| 分辨率 | 1280–1920 宽 | 先低分辨率试运动，再放大 |
| 种子 | 固定 | 同一条片复用种子与提示词 |

不同平台参数名不同，以上是**创作建议**，不是某个工具的硬性参数。

## 长片拼接

1. 先做 4–6 张风格化关键帧（同一色板、同一纸纹、同一光源方向）。
2. 每条 5–8 秒，只做一个运动；相邻镜头的主体在画面同一侧、同一高度。
3. 转场只用四种：
   - **雾擦**：雾从一侧盖满，下一镜从雾里显出。
   - **绸带**：朱砂/靛蓝色带横穿画面。
   - **前景掠过**：树枝、人群、屋檐、马身擦过镜头。
   - **纸面收束**：画面退成一张纸/一个圆盘，再展开下一景。
4. 不要用白闪、黑场、旋转、缩放模糊来掩盖不接。
5. 统一后期：同一 LUT、同一纸纹、同一颗粒、同一暗角（很轻）。

## 稳定性约束

写进正向提示词，不要只写在负向里：

- `same face, same hairstyle, same costume, same marking pattern`
- `stable paper texture, stable grain, stable color palette`
- `consistent roof outline, consistent mountain silhouette`
- `anatomically correct legs, five fingers, single head`
- `locked horizon, locked camera height`

负向词：

```text
morphing, melting face, extra limbs, extra fingers, duplicate head, jitter, flicker, warping buildings, drifting mountains, rapid zoom, camera roll, text, watermark, logo, photoreal, 3D render, glossy, neon
```

## 失败修复

| 症状 | 修法 |
| --- | --- |
| 主体漂移/变形 | 降运动幅度；缩短到 4–5s；加尾帧；用局部遮罩锁定主体 |
| 背景建筑抖动 | 降 ControlNet 权重；背景改为纯色/雾；减少建筑细节 |
| 脸融化 | 改半身/近景；脸区单独低强度重绘；不要在大全景里给脸特写 |
| 多腿/多指 | 缩短镜头；避免奔跑；用首帧锁；后期局部修 |
| 闪烁/颗粒跳动 | 固定种子；降运动；后期加稳定颗粒；避免“胶片颗粒”提示词过强 |
| 颜色漂移 | 每一镜都写完整色板；后期统一 LUT；不要只写“蓝色调” |
| 运动像 PPT | 加雾、尘埃、衣摆、鬃毛的二级运动；镜头加极轻漂移 |

## 可选声音方向

原片音轨未分析。若用户要声音，只用“环境层”而非强节拍：低频风声、远处市集人声、马蹄/木铃、纸张摩擦。不要把鼓点、合成器 Drop 或旁白强加进这种克制的画面。
