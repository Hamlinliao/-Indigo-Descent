# 提示词库

所有模板都遵守同一结构：**风格锁 → 主体锁 → 构图 → 材质/光 → 负向**。风格锁逐字复用，只替换主体与构图。

## 1. 风格锁

### 中文·短版（日常够用）

```text
暖象牙旧纸上的东方岩彩电影插画，靛蓝与墨蓝建立结构，朱砂与赭金只作少量点睛，细刻线、矿物颗粒、干笔残缺边缘，雾层与大面积留白，低地平线，横向层叠空间，哑光无高光，像一张展开的旧绢。
```

### 中文·完整版

```text
暖象牙色旧纸/旧绢上的东方岩彩电影插画。以靛蓝、普鲁士蓝和墨蓝承担山体、衣袍与主体的结构，朱砂红只出现在缰绳、腰带、唇色或一两件饰物上，赭金与旧金用于日轮、金箔和干草。大色块平涂，边缘是干笔的毛边与残缺，内部有细刻线、等高线、涡卷与植物纹样，颜料颗粒与极稀疏的金箔屑。雾层把前中后景分开，留白占画面三分之一以上。低地平线，横向层叠的空间，哑光、无高光、无镜头光晕、无写实体积。整体像一张被展开的旧绢，而不是照片加了滤镜。
```

### English · short

```text
A cinematic mineral-pigment illustration on warm ivory paper. Indigo and ink-blue structure the forms; restrained vermilion and ochre accents; fine engraved contour lines, pigment granulation, dry-brush broken edges; drifting mist and generous negative space; low horizon, layered horizontal depth, matte finish, no specular highlights, like an unfolded aged silk scroll.
```

### English · full

```text
A cinematic mineral-pigment illustration on warm ivory paper, in the spirit of Eastern gouache and cave-mural painting. Indigo, Prussian blue and ink-blue carry the mountains, robes and the subject's dark masses; vermilion appears only on a bridle, sash, lips or one or two ornaments; ochre and old gold are reserved for the sun disc, gold leaf and dry grass. Broad flat color fields with dry-brush broken edges, interior contour lines, engraved swirls and botanical patterns, pigment granulation and sparse gold flecks. Drifting mist separates foreground, middle ground and distance; at least one third of the frame is breathing negative space. Low horizon, layered horizontal space, matte surface, no specular highlights, no lens flare, no photoreal volume. It should read as an unfolded aged silk scroll, not a photograph with a filter.
```

## 2. 构图块

### 巨物—微人

```text
主体占据画面中景的 45–65%，略偏左/右；地平线压在画面下四分之一；一个只有画面高度 3–8% 的深色剪影人物站在主体下方，背对或侧对镜头，作为比例尺；背景只保留一层远山、一层雾和一个赭金圆盘；主体视线方向留出大面积纸白。
```

```text
The subject occupies 45–65% of the middle ground, set slightly off-center. The horizon sits in the lower quarter. A tiny dark silhouette, only 3–8% of the frame height, stands below the subject with its back or profile to the camera as a scale witness. The background holds only one distant mountain band, one layer of mist and one ochre sun disc. Generous paper-white negative space opens in the direction of the subject's gaze.
```

### 山水卷轴

```text
低地平线；两到四层山体/云层/地面横向叠压，最近一层最暗、最远一层最淡；一条弯曲的水带或山路径从画面下方进入，导向中景的主体；天空占上部三分之一以上，纸白与雾相接。
```

```text
Low horizon; two to four horizontal bands of mountain, cloud and ground overlap, the nearest darkest and the farthest palest. A winding waterway or mountain path enters from the lower edge and leads to the subject in the middle ground. Sky occupies more than the upper third, where paper white meets drifting mist.
```

### 剪影舞台

```text
前景用人群、屋檐、树枝或岩石压成 20–35% 的深色剪影，边缘被雾吃掉；主体在中景被这些剪影框住；背景是大色块的山影与雾，像一座戏台；人群高低错落，不画五官。
```

```text
The foreground is compressed into a 20–35% dark silhouette band of crowd, eaves, branches or rocks, its edges eaten by mist. The subject is framed in the middle ground by these silhouettes. The background is a stage-like field of broad mountain shapes and mist. The crowd rises and falls unevenly, with no facial features.
```

## 3. 主体锁

### 人像

```text
同一个人，保持同一张脸、同一发型、同一副眼镜/疤痕/痣；半身或全身，平面侧脸或四分之三脸，只保留一个暗色眼窝、一条鼻线、一点朱砂唇色；穿靛蓝立领长袍或深色宽袖衣，腰间一条朱砂带；不磨皮，不画睫毛高光。
```

```text
The same person, with the same face shape, hairstyle, glasses, scar or mole. Half or full body, flat profile or three-quarter view, keeping only a dark eye socket, one nose line and a touch of vermilion on the lips. Dressed in an indigo high-collar robe or dark wide-sleeved garment with a vermilion sash. No skin smoothing, no eyelash highlights.
```

### 宠物

```text
同一只宠物，保持物种、毛色分区、耳形、尾形和花纹；把它放大成纪念碑式的存在，占据画面 55–70%；毛发的明暗被压成几块平涂，花纹转成细刻线或印花；眼睛保留一个小小的骨白高光点。
```

```text
The same pet, keeping its species, coat markings, ear shape, tail shape and pattern. Enlarged into a monumental presence occupying 55–70% of the frame. Fur is simplified into a few flat value blocks; markings become fine engraved lines or printed patterns. The eyes keep one small bone-white catchlight.
```

### 产品

```text
同一件产品，保持外形、比例、结构、材质和 logo 位置；像被供奉的器物放在低台或纸面上，占画面 35–50%；材质转为哑光陶/漆/旧玻璃；旁边一条朱砂缎带，背景一个赭金圆盘和极小的剪影人物；文字与 logo 留给后期，不生成。
```

```text
The same product, keeping its silhouette, proportions, structure, material and logo placement. Presented like a votive object on a low plinth or paper floor, occupying 35–50% of the frame. Material becomes matte ceramic, lacquer or aged glass. A vermilion ribbon lies beside it; an ochre disc and a tiny silhouette figure sit in the background. All text and logos are added in post, never generated.
```

### 建筑

```text
同一座建筑，保持屋顶轮廓、开间节奏、标志性构件和朝向；屋顶与墙体压成靛蓝/墨蓝剪影，墙面留纸白，窗洞点赭金；檐口用细线勾出；建筑占 30–50%，低地平线，前景一枝枯树或一个挑担人压边。
```

```text
The same building, keeping its roof outline, bay rhythm, signature elements and orientation. Roofs and walls are compressed into indigo and ink-blue silhouettes; wall planes stay paper-white; window openings are dotted with ochre. Eaves are drawn with fine lines. The building occupies 30–50% of the frame under a low horizon, with a bare branch or a carrying figure pressing the foreground edge.
```

### 风景

```text
同一片地景，保持地标轮廓、山形、水岸线与相对位置；两到四层山体，最近最暗、最远最淡；山体用靛蓝平涂加干笔边缘，雾用纸白擦出；一条弯曲水带或山路；一个赭金日轮，一个微小旅人。
```

```text
The same landscape, keeping the landmark silhouette, mountain shapes, shoreline and relative positions. Two to four mountain layers, nearest darkest and farthest palest. Mountains are flat indigo with dry-brush edges; mist is wiped out of paper white. A winding waterway or path; one ochre sun disc; one tiny traveler.
```

### 街拍/群像

```text
同一组人物，主体保留颜色与识别点，站在中景；前景 25–35% 是墨蓝人群剪影，高低错落，边缘被雾吃掉，不画五官；背景是抽象的屋檐、幡和山影；只保留一到两件道具：伞、灯笼、挑担或幡。
```

```text
The same group, with the main subjects keeping their color and identifying features in the middle ground. The foreground is 25–35% ink-blue crowd silhouettes, rising and falling unevenly, edges eaten by mist, no facial features. The background is an abstract field of eaves, banners and mountain shadows. Keep only one or two props: umbrella, lantern, carrying pole or banner.
```

### 时装/角色

```text
同一角色，保持轮廓、发型、标志性配饰与服装结构；主体占 60–75%，硬边剪影，服装内部用金线、朱砂印花和细刻线建立纹样；背景是单色靛蓝或朱砂色块加稀疏金箔颗粒；脸只留一条侧线和一个暗色眼睛。
```

```text
The same character, keeping the silhouette, hairstyle, signature accessories and garment structure. The subject occupies 60–75% of the frame as a hard-edged silhouette; the garment interior carries gold lines, vermilion prints and fine engraved patterns. The background is a single indigo or vermilion field with sparse gold flecks. The face keeps only one profile line and one dark eye.
```

## 4. 负向词

### 中文

```text
写实摄影，3D 渲染，塑料高光，镜面反射，HDR，镜头光晕，景深虚化，赛博霓虹，荧光色，糖果色，日式赛璐璐动画，游戏原画，厚涂概念图，过度锐化，全画面密集细节，随机文字，书法，印章，水印，边框，签名，多余肢体，多指，多腿，双头，脸融化，主体变形，装饰吞没主体
```

### English

```text
photorealistic, 3D render, plastic specular highlights, mirror reflection, HDR, lens flare, shallow depth of field, cyberpunk neon, fluorescent colors, candy palette, Japanese cel animation, game concept art, thick impasto concept painting, over-sharpened, dense detail everywhere, random text, calligraphy, seal stamp, watermark, border, signature, extra limbs, extra fingers, extra legs, two heads, melting face, distorted subject, ornament swallowing the subject
```

## 5. 平台写法

### Midjourney

```text
/imagine prompt: [主体锁] + [构图块] + [风格锁] --ar 16:9 --sref <风格图URL> --sw 200 --stylize 150 --no photo, 3d render, text, watermark
```

- `--sref` 接风格图 URL；`--sw` 控制风格强度，起始 150–300。
- 原图作 image prompt 时可用 `--iw 0.8–1.2`；只做风格参考时不要堆太多图。
- 版本差异大，参数以当前版本为准；不要迷信固定数值。

### Stable Diffusion / ComfyUI

正向用完整版风格锁 + 主体锁；负向用上面的英文负向词。图生图重绘 0.45–0.6，Depth 0.35–0.5，Lineart 0.25–0.4；主体遮罩单独降强度。详见 [图片转译](image-transfer.md)。

### 即梦 / 可灵 / 通义万相

图生图选“参考图/结构参考”，强度 0.45–0.65；风格参考另附一张静帧；主体描述放最前；负向词如果平台不支持，就把“no photo, no 3D, no text”写进正向句尾。

## 6. 完整示例

### 示例 A：人像

```text
暖象牙旧纸上的东方岩彩电影插画，靛蓝与墨蓝建立结构，朱砂与赭金只作少量点睛，细刻线、矿物颗粒、干笔残缺边缘，雾层与大面积留白，低地平线，横向层叠空间，哑光无高光，像一张展开的旧绢。
同一个年轻女子，保持同一张圆脸、同一头齐耳短发、同一副圆框眼镜；半身，平面四分之三侧脸，只留一个暗色眼窝、一条鼻线、一点朱砂唇色；穿靛蓝立领长袍，腰间一条朱砂细带。
她位于画面右侧，视线向左；左侧留出大面积纸白；身后一层远山淡影和一个赭金圆盘；画面左下角一个只有 5% 高的深色剪影人物，作为比例尺。
负向：写实摄影，3D 渲染，塑料高光，HDR，镜头光晕，赛博霓虹，日式赛璐璐，随机文字，水印，多余肢体，脸崩。
```

### 示例 B：宠物

```text
暖象牙旧纸上的东方岩彩电影插画，靛蓝与墨蓝建立结构，朱砂与赭金只作少量点睛，细刻线、矿物颗粒、干笔残缺边缘，雾层与大面积留白，低地平线，横向层叠空间，哑光无高光。
同一只柴犬，保持黄白毛色分区、立耳、卷尾和眉点；把它放大成纪念碑式的存在，占画面 60%，坐在画面偏左；毛发压成几块平涂，花纹转成细刻线；眼睛保留一个小小的骨白高光。
右侧一个只有 4% 高的深色剪影农夫，肩挑扁担；背景两层靛蓝远山、一片纸白雾谷和一个赭金日轮。
负向：写实摄影，3D 渲染，塑料高光，换物种，加鬃毛，多腿，随机文字，水印，过度锐化。
```

### 示例 C：产品

```text
暖象牙旧纸上的东方岩彩电影插画，靛蓝与墨蓝建立结构，朱砂与赭金只作少量点睛，细刻线、矿物颗粒、干笔残缺边缘，雾层与大面积留白，低地平线，哑光无高光。
同一只方形琥珀色香水瓶，保持瓶身比例、瓶盖结构和正面标签位置；像被供奉的器物放在一块低矮石台上，占画面 40%，略偏右；瓶身转为哑光旧玻璃，标签留白，不生成文字。
一条朱砂缎带从台前垂落；背景一面靛蓝雾幕和一个赭金圆盘；左下角一个 3% 高的深色剪影人物仰望。
负向：写实摄影，3D 渲染，塑料高光，镜面反射，改 logo，随机文字，水印，瓶身变形，多余结构。
```

### 示例 D：风景

```text
暖象牙旧纸上的东方岩彩电影插画，靛蓝与墨蓝建立结构，朱砂与赭金只作少量点睛，细刻线、矿物颗粒、干笔残缺边缘，雾层与大面积留白，低地平线，横向层叠空间，哑光无高光。
贵州兴义式层叠喀斯特峰丛，保持近景山脊、中景谷地和远处峰林的相对位置；三层山体，最近最暗、最远最淡；山体靛蓝平涂加干笔边缘，雾用纸白擦出；一条弯曲山路从右下进入谷地。
右侧一个赭金日轮，被山脊遮住三分之一；山路上一个 3% 高的深色旅人牵马。
负向：写实摄影，3D 渲染，塑料高光，HDR，镜头光晕，富士山，阿尔卑斯，随机文字，水印，满山细节。
```

## 7. 提示词卫生

- 一条提示词只用一个风格体系。不要把“水墨、岩彩、赛博、巴洛克、吉卜力”堆在一起。
- 颜色写“角色”，不要只写“蓝色调”：靛蓝负责结构，朱砂负责点睛，赭金负责时间。
- 主体描述用肯定句，不要只写“不要变”。模型对“不要”经常反向理解。
- 负向词不要超过 40 个；太多会互相打架，也会把风格细节一起删掉。
- 每次只改一个变量（构图、强度、色比），否则无法判断哪一步有效。
- 同一系列复用同一段风格锁与同一张纸纹；一致性来自重复，不来自形容词堆叠。
