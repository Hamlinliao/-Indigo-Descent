# Preview assets

## From the original artwork

These files contain stills from the interactive artworks 《下山》 and 《贵州兴义》 by Liao Huimin (Hamlin). They are licensed under **CC BY-NC 4.0** — non-commercial sharing and adaptation with attribution; commercial use requires separate permission.

- `still-01.jpg` — mountain, sun disc, tiny rider
- `still-02.jpg` — market, horse, mineral-color crowd
- `still-03.jpg` — mist, monumental horse, tiny human
- `still-04.jpg` — vermilion/indigo graphic variant
- `contact-sheet.jpg` — the four stills with labels
- `cover.jpg` — README cover, using `still-01`
- `motion-preview.gif` — ~3s motion sample from the second clip
- `lineage.jpg` — side-by-side comparison with the ink-wash 《贵州兴义》 study

## Generated diagrams

These are original diagrams created for this skill and released under the **MIT License**:

- `palette.png` — palette and pigment-ratio card
- `icon.png` — skill icon

The original video files are not included in this repository.
